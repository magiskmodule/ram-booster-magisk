MODDIR=${0%/*}
rm -rf $MODPATH/LICENSE
sleep 30
for i in $MODDIR/config/*; do
case $i in
*-ls|*-ls.sh);;
*) if [ -f "$i" -a -x "$i" ]; then $i & fi;;
esac
done
sleep 5
am start -a android.intent.action.VIEW -d https://t.me/godTspeed >/dev/null 2>&1
am start -a android.intent.action.VIEW -d https://t.me/godspeedmode >/dev/null 2>&1