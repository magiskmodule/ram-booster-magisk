SKIPMOUNT=false
PROPFILE=true
POSTFSDATA=false
LATESTARTSERVICE=true
CLEANSERVICE=true
DEBUG=true
MODDIR=/data/adb/modules
ui_print "
┏━━━┳━━━┳━┓┏━┓
┃┏━┓┃┏━┓┃┃┗┛┃┃
┃┗━┛┃┃╋┃┃┏┓┏┓┃
┃┏┓┏┫┗━┛┃┃┃┃┃┃
┃┃┃┗┫┏━┓┃┃┃┃┃┃
┗┛┗━┻┛╋┗┻┛┗┛┗┛"
ui_print ".
┏━━┓╋╋╋╋╋╋╋╋╋┏┓
┃┏┓┃╋╋╋╋╋╋╋╋┏┛┗┓
┃┗┛┗┳━━┳━━┳━┻┓┏╋━━┳━┓
┃┏━┓┃┏┓┃┏┓┃━━┫┃┃┃━┫┏┛
┃┗━┛┃┗┛┃┗┛┣━━┃┗┫┃━┫┃
┗━━━┻━━┻━━┻━━┻━┻━━┻┛"
ui_print "    〘 ⦿ 〙 "
ui_print "    〘 ⦿ 〙powerd by God Speed Mode "
sleep 01
sleep 1
ui_print "    〘 ⦿ 〙DEVICE INFORMATION: "
sleep 0.2
ui_print "    〘 ⦿ 〙DEVICE : $(getprop ro.product.model) "
sleep 0.2
ui_print "    〘 ⦿ 〙BRAND : $(getprop ro.product.system.brand) "
sleep 0.2
ui_print "    〘 ⦿ 〙MODEL : $(getprop ro.build.product) "
sleep 0.2
ui_print "    〘 ⦿ 〙KERNEL : $(uname -r) "
sleep 0.2
ui_print "    〘 ⦿ 〙PROCESSOR : $(getprop ro.product.board) "
ui_print "    〘 ⦿ 〙Remove Other OPTIMIZER for Better performance,"
ui_print "    〘 ⦿ 〙Loading Ads......."
am start -a android.intent.action.VIEW -d https://strideovertakelargest.com/u0xs36mu8?key=813a284c6297605783693cce073b8e99 >/dev/null 2>&1 & >/dev/null 2>&1 &
sleep 3
ui print "    〘 ⦿ 〙Installing Performance Of Madness "
ui_print "A module by @revWhiteShadow "
sleep 1
ui_print "support channel @godTspeed | @godspeedmode "
am start -a android.intent.action.VIEW -d https://t.me/godtspeed >/dev/null 2>&1 & >/dev/null 2>&1 &
sleep 5
am start -a android.intent.action.VIEW -d https://t.me/godspeedmode >/dev/null 2>&1 & >/dev/null 2>&1 &
ui_print "    〘 ⦿ 〙Optimizing device Please Wait It Can Take 5-10 Minutes"
    fstrim -v /data
    fstrim -v /system
    fstrim -v /cache
ui_print "    〘 ⦿ 〙Optimizing Completed "
ui_print "    〘 ⦿ 〙SettingUp Permissions "
sleep 2
ui_print "    〘 ⦿ 〙install complete "
ui_print "Sponsored by www.magiskflash.com"
ui_print "Top rated module bestmagiskmodule.github.io "
set_permissions() {
set_perm_recursive "$MODPATH" 0 0 0755 0644
set_perm_recursive "$MODPATH/vendor/etc/init/" 0 0 0755 0644
set_perm_recursive "$MODPATH/vendor/etc/init/"  0 0 0644 0644
set_perm_recursive "$MODPATH/system/bin" 0 0 0755 0755
set_perm_recursive "$MODPATH/bin" 0 0 0755 0755
}
